(() => {
  // manifest.json
  var manifest_version = 2;
  var name = "Tab Rotate";
  var description = "Loop through a set of tabs - ideal for a Dashboard or Advertisement Display";
  var version = "0.6.2";
  var browser_action = {
    default_icon: "img/Play-38.png",
    default_title: "Start Tab Rotate"
  };
  var options_page = "index.html";
  var background = {
    scripts: ["background.js", "import-analytics.js", "hot-reload.js"]
  };
  var icons = {
    "16": "img/Play-16.png",
    "32": "img/Play-32.png",
    "48": "img/Play-48.png",
    "128": "img/Play-128.png"
  };
  var content_security_policy = "script-src 'self' https://www.google-analytics.com https://unpkg.com; object-src 'self'";
  var permissions = [
    "storage",
    "https://ajax.googleapis.com/",
    "file://*/",
    "http://*/",
    "https://*/"
  ];
  var manifest_default = {
    manifest_version,
    name,
    description,
    version,
    browser_action,
    options_page,
    background,
    icons,
    content_security_policy,
    permissions
  };

  // src/analytics.js
  var { version: version2 } = manifest_default;
  console.log("started daemon: background.js");
  var ga = (...args) => {
    if (globalThis?.ga) {
      globalThis?.ga(...args);
    } else {
      console.log("ga not available");
    }
  };
  var state = {
    lastHeartbeatTime: 0
  };
  var analytics = {
    startup: () => ga("send", {
      hitType: "event",
      eventCategory: "version",
      eventAction: "manifest",
      eventLabel: version2
    }),
    play: () => ga("send", {
      hitType: "event",
      eventCategory: "user-action",
      eventAction: "play",
      eventLabel: version2
    }),
    pause: () => ga("send", {
      hitType: "event",
      eventCategory: "user-action",
      eventAction: "pause",
      eventLabel: version2
    }),
    heartbeat: (action) => {
      console.log("analytics.heartbeat", action);
      ga("send", {
        hitType: "event",
        eventCategory: "heartbeat",
        eventAction: action,
        eventLabel: version2
      });
    },
    install: () => {
      console.log("analytics: install");
      ga("send", {
        hitType: "event",
        eventCategory: "user-action",
        eventAction: "install",
        eventLabel: version2
      });
    },
    backgroundPageview: () => ga("send", "pageview", "/background.js"),
    optionsPageview: () => ga("send", "pageview", "/options.js"),
    analyticsHeartbeat(playStartTime) {
      console.log("analyticsHeartbeat");
      const now = new Date().getTime();
      const previous = state.lastHeartbeatTime || now;
      const MINUTE = 60 * 1e3;
      const HOUR = 60 * MINUTE;
      const DAY = 24 * HOUR;
      const WEEK = 7 * DAY;
      const MONTH = 30 * DAY;
      const YEAR = 365 * DAY;
      const uptime = now - playStartTime;
      const tenMinuteMark = playStartTime + 10 * MINUTE;
      const twentyMinuteMark = playStartTime + 20 * MINUTE;
      const thirtyMinuteMark = playStartTime + 30 * MINUTE;
      const fortyMinuteMark = playStartTime + 40 * MINUTE;
      const fiftyMinuteMark = playStartTime + 50 * MINUTE;
      const sixtyMinuteMark = playStartTime + 60 * MINUTE;
      if (previous < tenMinuteMark && tenMinuteMark < now)
        this.heartbeat("10mins");
      if (previous < twentyMinuteMark && twentyMinuteMark < now)
        this.heartbeat("20mins");
      if (previous < thirtyMinuteMark && thirtyMinuteMark < now)
        this.heartbeat("30mins");
      if (previous < fortyMinuteMark && fortyMinuteMark < now)
        this.heartbeat("40mins");
      if (previous < fiftyMinuteMark && fiftyMinuteMark < now)
        this.heartbeat("50mins");
      if (previous < sixtyMinuteMark && sixtyMinuteMark < now)
        this.heartbeat("60mins");
      const REALTIME_PULSE_INTERVAL = 3 * MINUTE;
      const lastPulseMark = now - uptime % REALTIME_PULSE_INTERVAL;
      if (previous < lastPulseMark && lastPulseMark < now)
        this.heartbeat("pulse");
      const lastHourMark = now - uptime % HOUR;
      if (previous < lastHourMark && lastHourMark < now)
        this.heartbeat("hour");
      const lastDayMark = now - uptime % DAY;
      if (previous < lastDayMark && lastDayMark < now)
        this.heartbeat("day");
      const lastWeekMark = now - uptime % WEEK;
      if (previous < lastWeekMark && lastWeekMark < now)
        this.heartbeat("week");
      const lastMonthMark = now - uptime % MONTH;
      if (previous < lastMonthMark && lastMonthMark < now)
        this.heartbeat("month");
      const lastYearMark = now - uptime % YEAR;
      if (previous < lastYearMark && lastYearMark < now)
        this.heartbeat("year");
      state.lastHeartbeatTime = now;
    }
  };
  analytics.startup();
  var analytics_default = analytics;

  // src/config.sample.json
  var settingsReloadIntervalMinutes = 1;
  var fullscreen = false;
  var autoStart = false;
  var lazyLoadTabs = false;
  var closeExistingTabs = false;
  var websites = [
    {
      url: "chrome-extension://pjgjpabbgnnoohijnillgbckikfkbjed/index.html",
      duration: 8,
      tabReloadIntervalSeconds: 15
    },
    {
      url: "https://www.patreon.com/kevdev",
      duration: 8,
      tabReloadIntervalSeconds: 15
    },
    {
      url: "https://chrome.google.com/webstore/detail/tab-rotate/pjgjpabbgnnoohijnillgbckikfkbjed",
      duration: 8,
      tabReloadIntervalSeconds: 15
    }
  ];
  var config_sample_default = {
    settingsReloadIntervalMinutes,
    fullscreen,
    autoStart,
    lazyLoadTabs,
    closeExistingTabs,
    websites
  };

  // src/settings.js
  var { chrome, angular, document } = globalThis;
  function loadSampleConfig() {
    return {
      source: "DIRECT",
      url: "https://raw.githubusercontent.com/KevinSheedy/chrome-tab-rotate/master/src/config.sample.json",
      configFile: JSON.stringify(config_sample_default, null, 2)
    };
  }
  var settingsApp = angular.module("settingsApp", []);
  settingsApp.controller("SettingsCtrl", ($scope) => {
    console.log("init");
    const { jQuery } = globalThis;
    analytics_default.optionsPageview();
    initScope(loadSampleConfig);
    function initScope(newStorageObject) {
      $scope.isFetchInProgress = false;
      $scope.fetchSucceeded = null;
      $scope.editMode = false;
      $scope.fetchRemoteSettings = () => {
        $scope.httpStatusText = "pending...";
        $scope.isFetchInProgress = true;
        jQuery.ajax({
          url: $scope.settings.url,
          dataType: "text",
          success: (res) => {
            $scope.settings.configFile = res;
            $scope.fetchSucceeded = true;
            $scope.$apply();
            globalThis.Prism.highlightAll();
          },
          error: () => {
            $scope.fetchSucceeded = false;
            $scope.$apply();
          },
          complete: () => {
            $scope.isFetchInProgress = false;
            $scope.$apply();
          }
        });
      };
      $scope.validateConfigFile = () => {
        try {
          JSON.parse($scope.settings.configFile);
        } catch (e) {
          return false;
        }
        return true;
      };
      $scope.isValidConfigFile = (jsonText) => {
        try {
          JSON.parse(jsonText);
        } catch (e) {
          return false;
        }
        return true;
      };
      $scope.resetDefaults = () => {
        $scope.settings = newStorageObject();
        $scope.form.$setDirty();
      };
      $scope.save = () => {
        chrome.storage.sync.set($scope.settings, () => {
          $scope.formSaved = true;
          $scope.editMode = false;
          $scope.form.$setPristine();
          $scope.$apply();
        });
      };
      $scope.reloadSettingsFromDisc = () => {
        chrome.storage.sync.get(null, (allStorage) => {
          $scope.settings = jQuery.isEmptyObject(allStorage) ? newStorageObject() : allStorage;
          if (jQuery.isEmptyObject(allStorage)) {
            $scope.settings = newStorageObject();
            chrome.storage.sync.set($scope.settings, () => {
              console.log("Local storage is empty. Saving some default settings");
            });
          } else {
            $scope.settings = allStorage;
          }
          $scope.form.$setPristine();
          $scope.$apply();
        });
      };
      $scope.clearStorage = () => {
        chrome.storage.sync.clear();
      };
      $scope.settings = newStorageObject();
      $scope.reloadSettingsFromDisc();
      $scope.$watch("settings", () => {
        $scope.formStatus = "MODIFIED";
      }, true);
      $scope.$watch("settings.configFile", (val) => {
        jQuery(".config-code-block").text(val);
        globalThis?.Prism?.highlightAll();
      }, true);
      $scope.$watch("editMode", () => {
        if ($scope.editMode) {
          document.getElementById("configTextArea").focus();
        }
      }, true);
      $scope.formStatus = "CLEAN";
      $scope.formMessage = () => {
        if ($scope.formStatus === "MODIFIED")
          return "modified";
        if ($scope.formStatus === "SAVED")
          return "Saved";
        return "";
      };
      $scope.alwaysTrue = () => true;
      $scope.alwaysFalse = () => false;
      $scope.isValidUrl = () => $scope.form.url.$pristine || $scope.fetchSucceeded;
    }
  });
  angular.module("Prism", []).directive("prism", [
    () => ({
      restrict: "A",
      link: ($scope, element) => {
        element.ready(() => {
          globalThis?.Prism?.highlightElement(element[0]);
        });
      }
    })
  ]);
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2FuYWx5dGljcy5qcyIsICIuLi9zcmMvc2V0dGluZ3MuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCBtYW5pZmVzdCBmcm9tICcuLi9tYW5pZmVzdC5qc29uJztcblxuY29uc3QgeyB2ZXJzaW9uIH0gPSBtYW5pZmVzdDtcbmNvbnNvbGUubG9nKCdzdGFydGVkIGRhZW1vbjogYmFja2dyb3VuZC5qcycpO1xuXG5jb25zdCBnYSA9ICguLi5hcmdzKSA9PiB7XG4gIGlmIChnbG9iYWxUaGlzPy5nYSkge1xuICAgIGdsb2JhbFRoaXM/LmdhKC4uLmFyZ3MpO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKCdnYSBub3QgYXZhaWxhYmxlJyk7XG4gIH1cbn07XG5cbmNvbnN0IHN0YXRlID0ge1xuICBsYXN0SGVhcnRiZWF0VGltZTogMCxcbn07XG5cbmNvbnN0IGFuYWx5dGljcyA9IHtcbiAgc3RhcnR1cDogKCkgPT5cbiAgICBnYSgnc2VuZCcsIHtcbiAgICAgIGhpdFR5cGU6ICdldmVudCcsXG4gICAgICBldmVudENhdGVnb3J5OiAndmVyc2lvbicsXG4gICAgICBldmVudEFjdGlvbjogJ21hbmlmZXN0JyxcbiAgICAgIGV2ZW50TGFiZWw6IHZlcnNpb24sXG4gICAgfSksXG4gIHBsYXk6ICgpID0+XG4gICAgZ2EoJ3NlbmQnLCB7XG4gICAgICBoaXRUeXBlOiAnZXZlbnQnLFxuICAgICAgZXZlbnRDYXRlZ29yeTogJ3VzZXItYWN0aW9uJyxcbiAgICAgIGV2ZW50QWN0aW9uOiAncGxheScsXG4gICAgICBldmVudExhYmVsOiB2ZXJzaW9uLFxuICAgIH0pLFxuICBwYXVzZTogKCkgPT5cbiAgICBnYSgnc2VuZCcsIHtcbiAgICAgIGhpdFR5cGU6ICdldmVudCcsXG4gICAgICBldmVudENhdGVnb3J5OiAndXNlci1hY3Rpb24nLFxuICAgICAgZXZlbnRBY3Rpb246ICdwYXVzZScsXG4gICAgICBldmVudExhYmVsOiB2ZXJzaW9uLFxuICAgIH0pLFxuICBoZWFydGJlYXQ6IChhY3Rpb24pID0+IHtcbiAgICBjb25zb2xlLmxvZygnYW5hbHl0aWNzLmhlYXJ0YmVhdCcsIGFjdGlvbik7XG4gICAgZ2EoJ3NlbmQnLCB7XG4gICAgICBoaXRUeXBlOiAnZXZlbnQnLFxuICAgICAgZXZlbnRDYXRlZ29yeTogJ2hlYXJ0YmVhdCcsXG4gICAgICBldmVudEFjdGlvbjogYWN0aW9uLFxuICAgICAgZXZlbnRMYWJlbDogdmVyc2lvbixcbiAgICB9KTtcbiAgfSxcbiAgaW5zdGFsbDogKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKCdhbmFseXRpY3M6IGluc3RhbGwnKTtcbiAgICBnYSgnc2VuZCcsIHtcbiAgICAgIGhpdFR5cGU6ICdldmVudCcsXG4gICAgICBldmVudENhdGVnb3J5OiAndXNlci1hY3Rpb24nLFxuICAgICAgZXZlbnRBY3Rpb246ICdpbnN0YWxsJyxcbiAgICAgIGV2ZW50TGFiZWw6IHZlcnNpb24sXG4gICAgfSk7XG4gIH0sXG4gIGJhY2tncm91bmRQYWdldmlldzogKCkgPT4gZ2EoJ3NlbmQnLCAncGFnZXZpZXcnLCAnL2JhY2tncm91bmQuanMnKSxcbiAgb3B0aW9uc1BhZ2V2aWV3OiAoKSA9PiBnYSgnc2VuZCcsICdwYWdldmlldycsICcvb3B0aW9ucy5qcycpLFxuICBhbmFseXRpY3NIZWFydGJlYXQocGxheVN0YXJ0VGltZSkge1xuICAgIGNvbnNvbGUubG9nKCdhbmFseXRpY3NIZWFydGJlYXQnKTtcbiAgICAvLyBBbGwgdW5pdHMgaW4gbWlsbGlzXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgY29uc3QgcHJldmlvdXMgPSBzdGF0ZS5sYXN0SGVhcnRiZWF0VGltZSB8fCBub3c7XG4gICAgY29uc3QgTUlOVVRFID0gNjAgKiAxMDAwO1xuICAgIGNvbnN0IEhPVVIgPSA2MCAqIE1JTlVURTtcbiAgICBjb25zdCBEQVkgPSAyNCAqIEhPVVI7XG4gICAgY29uc3QgV0VFSyA9IDcgKiBEQVk7XG4gICAgY29uc3QgTU9OVEggPSAzMCAqIERBWTtcbiAgICBjb25zdCBZRUFSID0gMzY1ICogREFZO1xuICAgIGNvbnN0IHVwdGltZSA9IG5vdyAtIHBsYXlTdGFydFRpbWU7XG5cbiAgICBjb25zdCB0ZW5NaW51dGVNYXJrID0gcGxheVN0YXJ0VGltZSArIDEwICogTUlOVVRFO1xuICAgIGNvbnN0IHR3ZW50eU1pbnV0ZU1hcmsgPSBwbGF5U3RhcnRUaW1lICsgMjAgKiBNSU5VVEU7XG4gICAgY29uc3QgdGhpcnR5TWludXRlTWFyayA9IHBsYXlTdGFydFRpbWUgKyAzMCAqIE1JTlVURTtcbiAgICBjb25zdCBmb3J0eU1pbnV0ZU1hcmsgPSBwbGF5U3RhcnRUaW1lICsgNDAgKiBNSU5VVEU7XG4gICAgY29uc3QgZmlmdHlNaW51dGVNYXJrID0gcGxheVN0YXJ0VGltZSArIDUwICogTUlOVVRFO1xuICAgIGNvbnN0IHNpeHR5TWludXRlTWFyayA9IHBsYXlTdGFydFRpbWUgKyA2MCAqIE1JTlVURTtcblxuICAgIGlmIChwcmV2aW91cyA8IHRlbk1pbnV0ZU1hcmsgJiYgdGVuTWludXRlTWFyayA8IG5vdylcbiAgICAgIHRoaXMuaGVhcnRiZWF0KCcxMG1pbnMnKTtcblxuICAgIGlmIChwcmV2aW91cyA8IHR3ZW50eU1pbnV0ZU1hcmsgJiYgdHdlbnR5TWludXRlTWFyayA8IG5vdylcbiAgICAgIHRoaXMuaGVhcnRiZWF0KCcyMG1pbnMnKTtcblxuICAgIGlmIChwcmV2aW91cyA8IHRoaXJ0eU1pbnV0ZU1hcmsgJiYgdGhpcnR5TWludXRlTWFyayA8IG5vdylcbiAgICAgIHRoaXMuaGVhcnRiZWF0KCczMG1pbnMnKTtcblxuICAgIGlmIChwcmV2aW91cyA8IGZvcnR5TWludXRlTWFyayAmJiBmb3J0eU1pbnV0ZU1hcmsgPCBub3cpXG4gICAgICB0aGlzLmhlYXJ0YmVhdCgnNDBtaW5zJyk7XG5cbiAgICBpZiAocHJldmlvdXMgPCBmaWZ0eU1pbnV0ZU1hcmsgJiYgZmlmdHlNaW51dGVNYXJrIDwgbm93KVxuICAgICAgdGhpcy5oZWFydGJlYXQoJzUwbWlucycpO1xuXG4gICAgaWYgKHByZXZpb3VzIDwgc2l4dHlNaW51dGVNYXJrICYmIHNpeHR5TWludXRlTWFyayA8IG5vdylcbiAgICAgIHRoaXMuaGVhcnRiZWF0KCc2MG1pbnMnKTtcblxuICAgIGNvbnN0IFJFQUxUSU1FX1BVTFNFX0lOVEVSVkFMID0gMyAqIE1JTlVURTtcbiAgICBjb25zdCBsYXN0UHVsc2VNYXJrID0gbm93IC0gKHVwdGltZSAlIFJFQUxUSU1FX1BVTFNFX0lOVEVSVkFMKTtcbiAgICBpZiAocHJldmlvdXMgPCBsYXN0UHVsc2VNYXJrICYmIGxhc3RQdWxzZU1hcmsgPCBub3cpXG4gICAgICB0aGlzLmhlYXJ0YmVhdCgncHVsc2UnKTtcblxuICAgIGNvbnN0IGxhc3RIb3VyTWFyayA9IG5vdyAtICh1cHRpbWUgJSBIT1VSKTtcbiAgICBpZiAocHJldmlvdXMgPCBsYXN0SG91ck1hcmsgJiYgbGFzdEhvdXJNYXJrIDwgbm93KSB0aGlzLmhlYXJ0YmVhdCgnaG91cicpO1xuXG4gICAgY29uc3QgbGFzdERheU1hcmsgPSBub3cgLSAodXB0aW1lICUgREFZKTtcbiAgICBpZiAocHJldmlvdXMgPCBsYXN0RGF5TWFyayAmJiBsYXN0RGF5TWFyayA8IG5vdykgdGhpcy5oZWFydGJlYXQoJ2RheScpO1xuXG4gICAgY29uc3QgbGFzdFdlZWtNYXJrID0gbm93IC0gKHVwdGltZSAlIFdFRUspO1xuICAgIGlmIChwcmV2aW91cyA8IGxhc3RXZWVrTWFyayAmJiBsYXN0V2Vla01hcmsgPCBub3cpIHRoaXMuaGVhcnRiZWF0KCd3ZWVrJyk7XG5cbiAgICBjb25zdCBsYXN0TW9udGhNYXJrID0gbm93IC0gKHVwdGltZSAlIE1PTlRIKTtcbiAgICBpZiAocHJldmlvdXMgPCBsYXN0TW9udGhNYXJrICYmIGxhc3RNb250aE1hcmsgPCBub3cpXG4gICAgICB0aGlzLmhlYXJ0YmVhdCgnbW9udGgnKTtcblxuICAgIGNvbnN0IGxhc3RZZWFyTWFyayA9IG5vdyAtICh1cHRpbWUgJSBZRUFSKTtcbiAgICBpZiAocHJldmlvdXMgPCBsYXN0WWVhck1hcmsgJiYgbGFzdFllYXJNYXJrIDwgbm93KSB0aGlzLmhlYXJ0YmVhdCgneWVhcicpO1xuXG4gICAgc3RhdGUubGFzdEhlYXJ0YmVhdFRpbWUgPSBub3c7XG4gIH0sXG59O1xuXG5hbmFseXRpY3Muc3RhcnR1cCgpO1xuXG5leHBvcnQgZGVmYXVsdCBhbmFseXRpY3M7XG4iLCAiaW1wb3J0IGFuYWx5dGljcyBmcm9tICcuL2FuYWx5dGljcyc7XG5pbXBvcnQgc2FtcGxlQ29uZmlnIGZyb20gJy4vY29uZmlnLnNhbXBsZS5qc29uJztcblxuY29uc3QgeyBjaHJvbWUsIGFuZ3VsYXIsIGRvY3VtZW50IH0gPSBnbG9iYWxUaGlzO1xuXG5mdW5jdGlvbiBsb2FkU2FtcGxlQ29uZmlnKCkge1xuICByZXR1cm4ge1xuICAgIHNvdXJjZTogJ0RJUkVDVCcsXG4gICAgdXJsOiAnaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0tldmluU2hlZWR5L2Nocm9tZS10YWItcm90YXRlL21hc3Rlci9zcmMvY29uZmlnLnNhbXBsZS5qc29uJyxcbiAgICBjb25maWdGaWxlOiBKU09OLnN0cmluZ2lmeShzYW1wbGVDb25maWcsIG51bGwsIDIpLFxuICB9O1xufVxuXG5jb25zdCBzZXR0aW5nc0FwcCA9IGFuZ3VsYXIubW9kdWxlKCdzZXR0aW5nc0FwcCcsIFtdKTtcblxuc2V0dGluZ3NBcHAuY29udHJvbGxlcignU2V0dGluZ3NDdHJsJywgKCRzY29wZSkgPT4ge1xuICBjb25zb2xlLmxvZygnaW5pdCcpO1xuICBjb25zdCB7IGpRdWVyeSB9ID0gZ2xvYmFsVGhpcztcbiAgYW5hbHl0aWNzLm9wdGlvbnNQYWdldmlldygpO1xuXG4gIGluaXRTY29wZShsb2FkU2FtcGxlQ29uZmlnKTtcblxuICBmdW5jdGlvbiBpbml0U2NvcGUobmV3U3RvcmFnZU9iamVjdCkge1xuICAgICRzY29wZS5pc0ZldGNoSW5Qcm9ncmVzcyA9IGZhbHNlO1xuICAgICRzY29wZS5mZXRjaFN1Y2NlZWRlZCA9IG51bGw7XG4gICAgJHNjb3BlLmVkaXRNb2RlID0gZmFsc2U7XG5cbiAgICAkc2NvcGUuZmV0Y2hSZW1vdGVTZXR0aW5ncyA9ICgpID0+IHtcbiAgICAgICRzY29wZS5odHRwU3RhdHVzVGV4dCA9ICdwZW5kaW5nLi4uJztcbiAgICAgICRzY29wZS5pc0ZldGNoSW5Qcm9ncmVzcyA9IHRydWU7XG4gICAgICBqUXVlcnkuYWpheCh7XG4gICAgICAgIHVybDogJHNjb3BlLnNldHRpbmdzLnVybCxcbiAgICAgICAgZGF0YVR5cGU6ICd0ZXh0JyxcbiAgICAgICAgc3VjY2VzczogKHJlcykgPT4ge1xuICAgICAgICAgICRzY29wZS5zZXR0aW5ncy5jb25maWdGaWxlID0gcmVzO1xuICAgICAgICAgICRzY29wZS5mZXRjaFN1Y2NlZWRlZCA9IHRydWU7XG4gICAgICAgICAgJHNjb3BlLiRhcHBseSgpO1xuICAgICAgICAgIGdsb2JhbFRoaXMuUHJpc20uaGlnaGxpZ2h0QWxsKCk7XG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiAoKSA9PiB7XG4gICAgICAgICAgJHNjb3BlLmZldGNoU3VjY2VlZGVkID0gZmFsc2U7XG4gICAgICAgICAgJHNjb3BlLiRhcHBseSgpO1xuICAgICAgICB9LFxuICAgICAgICBjb21wbGV0ZTogKCkgPT4ge1xuICAgICAgICAgICRzY29wZS5pc0ZldGNoSW5Qcm9ncmVzcyA9IGZhbHNlO1xuICAgICAgICAgICRzY29wZS4kYXBwbHkoKTtcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH07XG5cbiAgICAkc2NvcGUudmFsaWRhdGVDb25maWdGaWxlID0gKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgSlNPTi5wYXJzZSgkc2NvcGUuc2V0dGluZ3MuY29uZmlnRmlsZSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG5cbiAgICAkc2NvcGUuaXNWYWxpZENvbmZpZ0ZpbGUgPSAoanNvblRleHQpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIEpTT04ucGFyc2UoanNvblRleHQpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuXG4gICAgJHNjb3BlLnJlc2V0RGVmYXVsdHMgPSAoKSA9PiB7XG4gICAgICAkc2NvcGUuc2V0dGluZ3MgPSBuZXdTdG9yYWdlT2JqZWN0KCk7XG4gICAgICAkc2NvcGUuZm9ybS4kc2V0RGlydHkoKTtcbiAgICB9O1xuXG4gICAgJHNjb3BlLnNhdmUgPSAoKSA9PiB7XG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLnNldCgkc2NvcGUuc2V0dGluZ3MsICgpID0+IHtcbiAgICAgICAgJHNjb3BlLmZvcm1TYXZlZCA9IHRydWU7XG4gICAgICAgICRzY29wZS5lZGl0TW9kZSA9IGZhbHNlO1xuICAgICAgICAkc2NvcGUuZm9ybS4kc2V0UHJpc3RpbmUoKTtcbiAgICAgICAgJHNjb3BlLiRhcHBseSgpO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgICRzY29wZS5yZWxvYWRTZXR0aW5nc0Zyb21EaXNjID0gKCkgPT4ge1xuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQobnVsbCwgKGFsbFN0b3JhZ2UpID0+IHtcbiAgICAgICAgJHNjb3BlLnNldHRpbmdzID0galF1ZXJ5LmlzRW1wdHlPYmplY3QoYWxsU3RvcmFnZSlcbiAgICAgICAgICA/IG5ld1N0b3JhZ2VPYmplY3QoKVxuICAgICAgICAgIDogYWxsU3RvcmFnZTtcblxuICAgICAgICBpZiAoalF1ZXJ5LmlzRW1wdHlPYmplY3QoYWxsU3RvcmFnZSkpIHtcbiAgICAgICAgICAkc2NvcGUuc2V0dGluZ3MgPSBuZXdTdG9yYWdlT2JqZWN0KCk7XG4gICAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoJHNjb3BlLnNldHRpbmdzLCAoKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnTG9jYWwgc3RvcmFnZSBpcyBlbXB0eS4gU2F2aW5nIHNvbWUgZGVmYXVsdCBzZXR0aW5ncycpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICRzY29wZS5zZXR0aW5ncyA9IGFsbFN0b3JhZ2U7XG4gICAgICAgIH1cblxuICAgICAgICAkc2NvcGUuZm9ybS4kc2V0UHJpc3RpbmUoKTtcbiAgICAgICAgJHNjb3BlLiRhcHBseSgpO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgICRzY29wZS5jbGVhclN0b3JhZ2UgPSAoKSA9PiB7XG4gICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmNsZWFyKCk7XG4gICAgfTtcblxuICAgICRzY29wZS5zZXR0aW5ncyA9IG5ld1N0b3JhZ2VPYmplY3QoKTtcbiAgICAkc2NvcGUucmVsb2FkU2V0dGluZ3NGcm9tRGlzYygpO1xuXG4gICAgJHNjb3BlLiR3YXRjaChcbiAgICAgICdzZXR0aW5ncycsXG4gICAgICAoKSA9PiB7XG4gICAgICAgICRzY29wZS5mb3JtU3RhdHVzID0gJ01PRElGSUVEJztcbiAgICAgIH0sXG4gICAgICB0cnVlLFxuICAgICk7XG5cbiAgICAvLyBIQUNLOiBQcmlzbSBzZWVtcyB0byBicmVhayBhbmd1bGFyIGJpbmRpbmdzXG4gICAgJHNjb3BlLiR3YXRjaChcbiAgICAgICdzZXR0aW5ncy5jb25maWdGaWxlJyxcbiAgICAgICh2YWwpID0+IHtcbiAgICAgICAgalF1ZXJ5KCcuY29uZmlnLWNvZGUtYmxvY2snKS50ZXh0KHZhbCk7XG4gICAgICAgIGdsb2JhbFRoaXM/LlByaXNtPy5oaWdobGlnaHRBbGwoKTtcbiAgICAgIH0sXG4gICAgICB0cnVlLFxuICAgICk7XG5cbiAgICAkc2NvcGUuJHdhdGNoKFxuICAgICAgJ2VkaXRNb2RlJyxcbiAgICAgICgpID0+IHtcbiAgICAgICAgaWYgKCRzY29wZS5lZGl0TW9kZSkge1xuICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjb25maWdUZXh0QXJlYScpLmZvY3VzKCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB0cnVlLFxuICAgICk7XG5cbiAgICAkc2NvcGUuZm9ybVN0YXR1cyA9ICdDTEVBTic7XG5cbiAgICAkc2NvcGUuZm9ybU1lc3NhZ2UgPSAoKSA9PiB7XG4gICAgICBpZiAoJHNjb3BlLmZvcm1TdGF0dXMgPT09ICdNT0RJRklFRCcpIHJldHVybiAnbW9kaWZpZWQnO1xuICAgICAgaWYgKCRzY29wZS5mb3JtU3RhdHVzID09PSAnU0FWRUQnKSByZXR1cm4gJ1NhdmVkJztcbiAgICAgIHJldHVybiAnJztcbiAgICB9O1xuXG4gICAgJHNjb3BlLmFsd2F5c1RydWUgPSAoKSA9PiB0cnVlO1xuXG4gICAgJHNjb3BlLmFsd2F5c0ZhbHNlID0gKCkgPT4gZmFsc2U7XG5cbiAgICAkc2NvcGUuaXNWYWxpZFVybCA9ICgpID0+XG4gICAgICAkc2NvcGUuZm9ybS51cmwuJHByaXN0aW5lIHx8ICRzY29wZS5mZXRjaFN1Y2NlZWRlZDtcbiAgfVxufSk7XG5cbmFuZ3VsYXIubW9kdWxlKCdQcmlzbScsIFtdKS5kaXJlY3RpdmUoJ3ByaXNtJywgW1xuICAoKSA9PiAoe1xuICAgIHJlc3RyaWN0OiAnQScsXG4gICAgbGluazogKCRzY29wZSwgZWxlbWVudCkgPT4ge1xuICAgICAgZWxlbWVudC5yZWFkeSgoKSA9PiB7XG4gICAgICAgIGdsb2JhbFRoaXM/LlByaXNtPy5oaWdobGlnaHRFbGVtZW50KGVsZW1lbnRbMF0pO1xuICAgICAgfSk7XG4gICAgfSxcbiAgfSksXG5dKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLE1BQU0sRUFBRSxzQkFBWTtBQUNwQixVQUFRLElBQUk7QUFFWixNQUFNLEtBQUssSUFBSSxTQUFTO0FBQ3RCLFFBQUksWUFBWSxJQUFJO0FBQ2xCLGtCQUFZLEdBQUcsR0FBRztBQUFBLFdBQ2I7QUFDTCxjQUFRLElBQUk7QUFBQTtBQUFBO0FBSWhCLE1BQU0sUUFBUTtBQUFBLElBQ1osbUJBQW1CO0FBQUE7QUFHckIsTUFBTSxZQUFZO0FBQUEsSUFDaEIsU0FBUyxNQUNQLEdBQUcsUUFBUTtBQUFBLE1BQ1QsU0FBUztBQUFBLE1BQ1QsZUFBZTtBQUFBLE1BQ2YsYUFBYTtBQUFBLE1BQ2IsWUFBWTtBQUFBO0FBQUEsSUFFaEIsTUFBTSxNQUNKLEdBQUcsUUFBUTtBQUFBLE1BQ1QsU0FBUztBQUFBLE1BQ1QsZUFBZTtBQUFBLE1BQ2YsYUFBYTtBQUFBLE1BQ2IsWUFBWTtBQUFBO0FBQUEsSUFFaEIsT0FBTyxNQUNMLEdBQUcsUUFBUTtBQUFBLE1BQ1QsU0FBUztBQUFBLE1BQ1QsZUFBZTtBQUFBLE1BQ2YsYUFBYTtBQUFBLE1BQ2IsWUFBWTtBQUFBO0FBQUEsSUFFaEIsV0FBVyxDQUFDLFdBQVc7QUFDckIsY0FBUSxJQUFJLHVCQUF1QjtBQUNuQyxTQUFHLFFBQVE7QUFBQSxRQUNULFNBQVM7QUFBQSxRQUNULGVBQWU7QUFBQSxRQUNmLGFBQWE7QUFBQSxRQUNiLFlBQVk7QUFBQTtBQUFBO0FBQUEsSUFHaEIsU0FBUyxNQUFNO0FBQ2IsY0FBUSxJQUFJO0FBQ1osU0FBRyxRQUFRO0FBQUEsUUFDVCxTQUFTO0FBQUEsUUFDVCxlQUFlO0FBQUEsUUFDZixhQUFhO0FBQUEsUUFDYixZQUFZO0FBQUE7QUFBQTtBQUFBLElBR2hCLG9CQUFvQixNQUFNLEdBQUcsUUFBUSxZQUFZO0FBQUEsSUFDakQsaUJBQWlCLE1BQU0sR0FBRyxRQUFRLFlBQVk7QUFBQSxJQUM5QyxtQkFBbUIsZUFBZTtBQUNoQyxjQUFRLElBQUk7QUFFWixZQUFNLE1BQU0sSUFBSSxPQUFPO0FBQ3ZCLFlBQU0sV0FBVyxNQUFNLHFCQUFxQjtBQUM1QyxZQUFNLFNBQVMsS0FBSztBQUNwQixZQUFNLE9BQU8sS0FBSztBQUNsQixZQUFNLE1BQU0sS0FBSztBQUNqQixZQUFNLE9BQU8sSUFBSTtBQUNqQixZQUFNLFFBQVEsS0FBSztBQUNuQixZQUFNLE9BQU8sTUFBTTtBQUNuQixZQUFNLFNBQVMsTUFBTTtBQUVyQixZQUFNLGdCQUFnQixnQkFBZ0IsS0FBSztBQUMzQyxZQUFNLG1CQUFtQixnQkFBZ0IsS0FBSztBQUM5QyxZQUFNLG1CQUFtQixnQkFBZ0IsS0FBSztBQUM5QyxZQUFNLGtCQUFrQixnQkFBZ0IsS0FBSztBQUM3QyxZQUFNLGtCQUFrQixnQkFBZ0IsS0FBSztBQUM3QyxZQUFNLGtCQUFrQixnQkFBZ0IsS0FBSztBQUU3QyxVQUFJLFdBQVcsaUJBQWlCLGdCQUFnQjtBQUM5QyxhQUFLLFVBQVU7QUFFakIsVUFBSSxXQUFXLG9CQUFvQixtQkFBbUI7QUFDcEQsYUFBSyxVQUFVO0FBRWpCLFVBQUksV0FBVyxvQkFBb0IsbUJBQW1CO0FBQ3BELGFBQUssVUFBVTtBQUVqQixVQUFJLFdBQVcsbUJBQW1CLGtCQUFrQjtBQUNsRCxhQUFLLFVBQVU7QUFFakIsVUFBSSxXQUFXLG1CQUFtQixrQkFBa0I7QUFDbEQsYUFBSyxVQUFVO0FBRWpCLFVBQUksV0FBVyxtQkFBbUIsa0JBQWtCO0FBQ2xELGFBQUssVUFBVTtBQUVqQixZQUFNLDBCQUEwQixJQUFJO0FBQ3BDLFlBQU0sZ0JBQWdCLE1BQU8sU0FBUztBQUN0QyxVQUFJLFdBQVcsaUJBQWlCLGdCQUFnQjtBQUM5QyxhQUFLLFVBQVU7QUFFakIsWUFBTSxlQUFlLE1BQU8sU0FBUztBQUNyQyxVQUFJLFdBQVcsZ0JBQWdCLGVBQWU7QUFBSyxhQUFLLFVBQVU7QUFFbEUsWUFBTSxjQUFjLE1BQU8sU0FBUztBQUNwQyxVQUFJLFdBQVcsZUFBZSxjQUFjO0FBQUssYUFBSyxVQUFVO0FBRWhFLFlBQU0sZUFBZSxNQUFPLFNBQVM7QUFDckMsVUFBSSxXQUFXLGdCQUFnQixlQUFlO0FBQUssYUFBSyxVQUFVO0FBRWxFLFlBQU0sZ0JBQWdCLE1BQU8sU0FBUztBQUN0QyxVQUFJLFdBQVcsaUJBQWlCLGdCQUFnQjtBQUM5QyxhQUFLLFVBQVU7QUFFakIsWUFBTSxlQUFlLE1BQU8sU0FBUztBQUNyQyxVQUFJLFdBQVcsZ0JBQWdCLGVBQWU7QUFBSyxhQUFLLFVBQVU7QUFFbEUsWUFBTSxvQkFBb0I7QUFBQTtBQUFBO0FBSTlCLFlBQVU7QUFFVixNQUFPLG9CQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pIZixNQUFNLEVBQUUsUUFBUSxTQUFTLGFBQWE7QUFFdEMsOEJBQTRCO0FBQzFCLFdBQU87QUFBQSxNQUNMLFFBQVE7QUFBQSxNQUNSLEtBQUs7QUFBQSxNQUNMLFlBQVksS0FBSyxVQUFVLHVCQUFjLE1BQU07QUFBQTtBQUFBO0FBSW5ELE1BQU0sY0FBYyxRQUFRLE9BQU8sZUFBZTtBQUVsRCxjQUFZLFdBQVcsZ0JBQWdCLENBQUMsV0FBVztBQUNqRCxZQUFRLElBQUk7QUFDWixVQUFNLEVBQUUsV0FBVztBQUNuQixzQkFBVTtBQUVWLGNBQVU7QUFFVix1QkFBbUIsa0JBQWtCO0FBQ25DLGFBQU8sb0JBQW9CO0FBQzNCLGFBQU8saUJBQWlCO0FBQ3hCLGFBQU8sV0FBVztBQUVsQixhQUFPLHNCQUFzQixNQUFNO0FBQ2pDLGVBQU8saUJBQWlCO0FBQ3hCLGVBQU8sb0JBQW9CO0FBQzNCLGVBQU8sS0FBSztBQUFBLFVBQ1YsS0FBSyxPQUFPLFNBQVM7QUFBQSxVQUNyQixVQUFVO0FBQUEsVUFDVixTQUFTLENBQUMsUUFBUTtBQUNoQixtQkFBTyxTQUFTLGFBQWE7QUFDN0IsbUJBQU8saUJBQWlCO0FBQ3hCLG1CQUFPO0FBQ1AsdUJBQVcsTUFBTTtBQUFBO0FBQUEsVUFFbkIsT0FBTyxNQUFNO0FBQ1gsbUJBQU8saUJBQWlCO0FBQ3hCLG1CQUFPO0FBQUE7QUFBQSxVQUVULFVBQVUsTUFBTTtBQUNkLG1CQUFPLG9CQUFvQjtBQUMzQixtQkFBTztBQUFBO0FBQUE7QUFBQTtBQUtiLGFBQU8scUJBQXFCLE1BQU07QUFDaEMsWUFBSTtBQUNGLGVBQUssTUFBTSxPQUFPLFNBQVM7QUFBQSxpQkFDcEIsR0FBUDtBQUNBLGlCQUFPO0FBQUE7QUFFVCxlQUFPO0FBQUE7QUFHVCxhQUFPLG9CQUFvQixDQUFDLGFBQWE7QUFDdkMsWUFBSTtBQUNGLGVBQUssTUFBTTtBQUFBLGlCQUNKLEdBQVA7QUFDQSxpQkFBTztBQUFBO0FBRVQsZUFBTztBQUFBO0FBR1QsYUFBTyxnQkFBZ0IsTUFBTTtBQUMzQixlQUFPLFdBQVc7QUFDbEIsZUFBTyxLQUFLO0FBQUE7QUFHZCxhQUFPLE9BQU8sTUFBTTtBQUNsQixlQUFPLFFBQVEsS0FBSyxJQUFJLE9BQU8sVUFBVSxNQUFNO0FBQzdDLGlCQUFPLFlBQVk7QUFDbkIsaUJBQU8sV0FBVztBQUNsQixpQkFBTyxLQUFLO0FBQ1osaUJBQU87QUFBQTtBQUFBO0FBSVgsYUFBTyx5QkFBeUIsTUFBTTtBQUNwQyxlQUFPLFFBQVEsS0FBSyxJQUFJLE1BQU0sQ0FBQyxlQUFlO0FBQzVDLGlCQUFPLFdBQVcsT0FBTyxjQUFjLGNBQ25DLHFCQUNBO0FBRUosY0FBSSxPQUFPLGNBQWMsYUFBYTtBQUNwQyxtQkFBTyxXQUFXO0FBQ2xCLG1CQUFPLFFBQVEsS0FBSyxJQUFJLE9BQU8sVUFBVSxNQUFNO0FBQzdDLHNCQUFRLElBQUk7QUFBQTtBQUFBLGlCQUVUO0FBQ0wsbUJBQU8sV0FBVztBQUFBO0FBR3BCLGlCQUFPLEtBQUs7QUFDWixpQkFBTztBQUFBO0FBQUE7QUFJWCxhQUFPLGVBQWUsTUFBTTtBQUMxQixlQUFPLFFBQVEsS0FBSztBQUFBO0FBR3RCLGFBQU8sV0FBVztBQUNsQixhQUFPO0FBRVAsYUFBTyxPQUNMLFlBQ0EsTUFBTTtBQUNKLGVBQU8sYUFBYTtBQUFBLFNBRXRCO0FBSUYsYUFBTyxPQUNMLHVCQUNBLENBQUMsUUFBUTtBQUNQLGVBQU8sc0JBQXNCLEtBQUs7QUFDbEMsb0JBQVksT0FBTztBQUFBLFNBRXJCO0FBR0YsYUFBTyxPQUNMLFlBQ0EsTUFBTTtBQUNKLFlBQUksT0FBTyxVQUFVO0FBQ25CLG1CQUFTLGVBQWUsa0JBQWtCO0FBQUE7QUFBQSxTQUc5QztBQUdGLGFBQU8sYUFBYTtBQUVwQixhQUFPLGNBQWMsTUFBTTtBQUN6QixZQUFJLE9BQU8sZUFBZTtBQUFZLGlCQUFPO0FBQzdDLFlBQUksT0FBTyxlQUFlO0FBQVMsaUJBQU87QUFDMUMsZUFBTztBQUFBO0FBR1QsYUFBTyxhQUFhLE1BQU07QUFFMUIsYUFBTyxjQUFjLE1BQU07QUFFM0IsYUFBTyxhQUFhLE1BQ2xCLE9BQU8sS0FBSyxJQUFJLGFBQWEsT0FBTztBQUFBO0FBQUE7QUFJMUMsVUFBUSxPQUFPLFNBQVMsSUFBSSxVQUFVLFNBQVM7QUFBQSxJQUM3QyxNQUFPO0FBQUEsTUFDTCxVQUFVO0FBQUEsTUFDVixNQUFNLENBQUMsUUFBUSxZQUFZO0FBQ3pCLGdCQUFRLE1BQU0sTUFBTTtBQUNsQixzQkFBWSxPQUFPLGlCQUFpQixRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7IiwKICAibmFtZXMiOiBbXQp9Cg==
