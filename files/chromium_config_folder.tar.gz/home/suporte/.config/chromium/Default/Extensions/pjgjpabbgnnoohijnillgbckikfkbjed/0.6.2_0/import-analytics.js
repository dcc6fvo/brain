(() => {
  // src/import-analytics.js
  console.log("import-analytics.js");
  var _AnalyticsId = "UA-109046965-1";
  (function(i, s, o, g, r, a, m) {
    i["GoogleAnalyticsObject"] = r;
    i[r] = i[r] || function() {
      (i[r].q = i[r].q || []).push(arguments);
    }, i[r].l = 1 * new Date();
    a = s.createElement(o), m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m);
  })(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga");
  ga("create", _AnalyticsId, "auto");
  ga("set", "checkProtocolTask", function() {
  });
  ga("require", "displayfeatures");
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2ltcG9ydC1hbmFseXRpY3MuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnNvbGUubG9nKCdpbXBvcnQtYW5hbHl0aWNzLmpzJyk7XG5cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbnZhciBfQW5hbHl0aWNzSWQgPSAnVUEtMTA5MDQ2OTY1LTEnO1xuXG4vLyBTdGFuZGFyZCBHb29nbGUgVW5pdmVyc2FsIEFuYWx5dGljcyBjb2RlXG5cbihmdW5jdGlvbiAoaSwgcywgbywgZywgciwgYSwgbSkge1xuICBpWydHb29nbGVBbmFseXRpY3NPYmplY3QnXSA9IHI7XG4gIChpW3JdID1cbiAgICBpW3JdIHx8XG4gICAgZnVuY3Rpb24gKCkge1xuICAgICAgKGlbcl0ucSA9IGlbcl0ucSB8fCBbXSkucHVzaChhcmd1bWVudHMpO1xuICAgIH0pLFxuICAgIChpW3JdLmwgPSAxICogbmV3IERhdGUoKSk7XG4gIChhID0gcy5jcmVhdGVFbGVtZW50KG8pKSwgKG0gPSBzLmdldEVsZW1lbnRzQnlUYWdOYW1lKG8pWzBdKTtcbiAgYS5hc3luYyA9IDE7XG4gIGEuc3JjID0gZztcbiAgbS5wYXJlbnROb2RlLmluc2VydEJlZm9yZShhLCBtKTtcbn0pKFxuICB3aW5kb3csXG4gIGRvY3VtZW50LFxuICAnc2NyaXB0JyxcbiAgJ2h0dHBzOi8vd3d3Lmdvb2dsZS1hbmFseXRpY3MuY29tL2FuYWx5dGljcy5qcycsXG4gICdnYScsXG4pOyAvLyBOb3RlOiBodHRwcyBwcm90b2NvbCBoZXJlXG5cbmdhKCdjcmVhdGUnLCBfQW5hbHl0aWNzSWQsICdhdXRvJyk7XG5cbmdhKCdzZXQnLCAnY2hlY2tQcm90b2NvbFRhc2snLCBmdW5jdGlvbiAoKSB7fSk7IC8vIFJlbW92ZXMgZmFpbGluZyBwcm90b2NvbCBjaGVjay4gQHNlZTogaHR0cDovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMjIxNTIzNTMvMTk1ODIwMFxuXG5nYSgncmVxdWlyZScsICdkaXNwbGF5ZmVhdHVyZXMnKTtcblxuLy9nYSgnc2VuZCcsICdwYWdldmlldycsICcvb3B0aW9ucy5odG1sJyk7XG5cbi8qIGVzbGludC1lbmFibGUgKi9cbiJdLAogICJtYXBwaW5ncyI6ICI7O0FBQUEsVUFBUSxJQUFJO0FBSVosTUFBSSxlQUFlO0FBSW5CLEVBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0FBQzlCLE1BQUUsMkJBQTJCO0FBQzdCLElBQUMsRUFBRSxLQUNELEVBQUUsTUFDRixXQUFZO0FBQ1YsTUFBQyxHQUFFLEdBQUcsSUFBSSxFQUFFLEdBQUcsS0FBSyxJQUFJLEtBQUs7QUFBQSxPQUU5QixFQUFFLEdBQUcsSUFBSSxJQUFJLElBQUk7QUFDcEIsSUFBQyxJQUFJLEVBQUUsY0FBYyxJQUFNLElBQUksRUFBRSxxQkFBcUIsR0FBRztBQUN6RCxNQUFFLFFBQVE7QUFDVixNQUFFLE1BQU07QUFDUixNQUFFLFdBQVcsYUFBYSxHQUFHO0FBQUEsS0FFN0IsUUFDQSxVQUNBLFVBQ0EsaURBQ0E7QUFHRixLQUFHLFVBQVUsY0FBYztBQUUzQixLQUFHLE9BQU8scUJBQXFCLFdBQVk7QUFBQTtBQUUzQyxLQUFHLFdBQVc7IiwKICAibmFtZXMiOiBbXQp9Cg==
