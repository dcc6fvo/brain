(() => {
  // src/hot-reload.js
  console.log("hot-reload.js");
  var chrome = window.chrome || {};
  var filesInDirectory = (dir) => new Promise((resolve) => dir.createReader().readEntries((entries) => Promise.all(entries.filter((e) => e.name[0] !== ".").map((e) => e.isDirectory ? filesInDirectory(e) : new Promise((res) => e.file(res)))).then((files) => [].concat(...files)).then(resolve)));
  var timestampForFilesInDirectory = (dir) => filesInDirectory(dir).then((files) => files.map((f) => f.name + f.lastModifiedDate).join());
  var watchChanges = (dir, lastTimestamp) => {
    timestampForFilesInDirectory(dir).then((timestamp) => {
      if (!lastTimestamp || lastTimestamp === timestamp) {
        setTimeout(() => watchChanges(dir, timestamp), 1e3);
      } else {
        chrome.runtime.reload();
      }
    });
  };
  chrome.management.getSelf((self) => {
    if (self.installType === "development") {
      chrome.runtime.getPackageDirectoryEntry((dir) => watchChanges(dir));
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
    }
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2hvdC1yZWxvYWQuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnNvbGUubG9nKCdob3QtcmVsb2FkLmpzJyk7XG5cbmNvbnN0IGNocm9tZSA9IHdpbmRvdy5jaHJvbWUgfHwge307XG5cbmNvbnN0IGZpbGVzSW5EaXJlY3RvcnkgPSAoZGlyKSA9PlxuICBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT5cbiAgICBkaXIuY3JlYXRlUmVhZGVyKCkucmVhZEVudHJpZXMoKGVudHJpZXMpID0+XG4gICAgICBQcm9taXNlLmFsbChcbiAgICAgICAgZW50cmllc1xuICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUubmFtZVswXSAhPT0gJy4nKVxuICAgICAgICAgIC5tYXAoKGUpID0+XG4gICAgICAgICAgICBlLmlzRGlyZWN0b3J5XG4gICAgICAgICAgICAgID8gZmlsZXNJbkRpcmVjdG9yeShlKVxuICAgICAgICAgICAgICA6IG5ldyBQcm9taXNlKChyZXMpID0+IGUuZmlsZShyZXMpKSxcbiAgICAgICAgICApLFxuICAgICAgKVxuICAgICAgICAudGhlbigoZmlsZXMpID0+IFtdLmNvbmNhdCguLi5maWxlcykpXG4gICAgICAgIC50aGVuKHJlc29sdmUpLFxuICAgICksXG4gICk7XG5cbmNvbnN0IHRpbWVzdGFtcEZvckZpbGVzSW5EaXJlY3RvcnkgPSAoZGlyKSA9PlxuICBmaWxlc0luRGlyZWN0b3J5KGRpcikudGhlbigoZmlsZXMpID0+XG4gICAgZmlsZXMubWFwKChmKSA9PiBmLm5hbWUgKyBmLmxhc3RNb2RpZmllZERhdGUpLmpvaW4oKSxcbiAgKTtcblxuY29uc3Qgd2F0Y2hDaGFuZ2VzID0gKGRpciwgbGFzdFRpbWVzdGFtcCkgPT4ge1xuICB0aW1lc3RhbXBGb3JGaWxlc0luRGlyZWN0b3J5KGRpcikudGhlbigodGltZXN0YW1wKSA9PiB7XG4gICAgaWYgKCFsYXN0VGltZXN0YW1wIHx8IGxhc3RUaW1lc3RhbXAgPT09IHRpbWVzdGFtcCkge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB3YXRjaENoYW5nZXMoZGlyLCB0aW1lc3RhbXApLCAxMDAwKTsgLy8gcmV0cnkgYWZ0ZXIgMXNcbiAgICB9IGVsc2Uge1xuICAgICAgY2hyb21lLnJ1bnRpbWUucmVsb2FkKCk7XG4gICAgfVxuICB9KTtcbn07XG5cbmNocm9tZS5tYW5hZ2VtZW50LmdldFNlbGYoKHNlbGYpID0+IHtcbiAgaWYgKHNlbGYuaW5zdGFsbFR5cGUgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICBjaHJvbWUucnVudGltZS5nZXRQYWNrYWdlRGlyZWN0b3J5RW50cnkoKGRpcikgPT4gd2F0Y2hDaGFuZ2VzKGRpcikpO1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBsYXN0Rm9jdXNlZFdpbmRvdzogdHJ1ZSB9LCAodGFicykgPT4ge1xuICAgICAgLy8gTkI6IHNlZSBodHRwczovL2dpdGh1Yi5jb20veHBsL2NyeC1ob3RyZWxvYWQvaXNzdWVzLzVcbiAgICAgIGlmICh0YWJzWzBdKSB7XG4gICAgICAgIGNocm9tZS50YWJzLnJlbG9hZCh0YWJzWzBdLmlkKTtcbiAgICAgICAgLy8gQSBiaXQgYW5ub3lpbmcgYXMgaXQgbWFrZXMgdGhlIGJyb3dzZXIganVtcCB0byB0aGUgZm9yZWdyb3VuZFxuICAgICAgICAvLyBjaHJvbWUucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOztBQUFBLFVBQVEsSUFBSTtBQUVaLE1BQU0sU0FBUyxPQUFPLFVBQVU7QUFFaEMsTUFBTSxtQkFBbUIsQ0FBQyxRQUN4QixJQUFJLFFBQVEsQ0FBQyxZQUNYLElBQUksZUFBZSxZQUFZLENBQUMsWUFDOUIsUUFBUSxJQUNOLFFBQ0csT0FBTyxDQUFDLE1BQU0sRUFBRSxLQUFLLE9BQU8sS0FDNUIsSUFBSSxDQUFDLE1BQ0osRUFBRSxjQUNFLGlCQUFpQixLQUNqQixJQUFJLFFBQVEsQ0FBQyxRQUFRLEVBQUUsS0FBSyxRQUduQyxLQUFLLENBQUMsVUFBVSxHQUFHLE9BQU8sR0FBRyxRQUM3QixLQUFLO0FBSWQsTUFBTSwrQkFBK0IsQ0FBQyxRQUNwQyxpQkFBaUIsS0FBSyxLQUFLLENBQUMsVUFDMUIsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxrQkFBa0I7QUFHbEQsTUFBTSxlQUFlLENBQUMsS0FBSyxrQkFBa0I7QUFDM0MsaUNBQTZCLEtBQUssS0FBSyxDQUFDLGNBQWM7QUFDcEQsVUFBSSxDQUFDLGlCQUFpQixrQkFBa0IsV0FBVztBQUNqRCxtQkFBVyxNQUFNLGFBQWEsS0FBSyxZQUFZO0FBQUEsYUFDMUM7QUFDTCxlQUFPLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFLckIsU0FBTyxXQUFXLFFBQVEsQ0FBQyxTQUFTO0FBQ2xDLFFBQUksS0FBSyxnQkFBZ0IsZUFBZTtBQUN0QyxhQUFPLFFBQVEseUJBQXlCLENBQUMsUUFBUSxhQUFhO0FBQzlELGFBQU8sS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLG1CQUFtQixRQUFRLENBQUMsU0FBUztBQUVyRSxZQUFJLEtBQUssSUFBSTtBQUNYLGlCQUFPLEtBQUssT0FBTyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTsiLAogICJuYW1lcyI6IFtdCn0K
